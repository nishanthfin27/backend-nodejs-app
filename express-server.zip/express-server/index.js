const express = require('express')
const mongoose = require('mongoose')
const app = express()
const port = 3010
app.use(express.json())

app.use((req, res, next) => {
    console.log(`${req.method} - ${req.url} - ${req.ip} - ${new Date()}`)
    next()
})

//establish connection to database
mongoose.connect('mongodb://localhost:27017/july-2020')
    .then(() => {
        console.log('connected to db')
    })
    .catch((err) => {
        console.log('error connecting to db', err)
    })

//create a task schema
const Schema = mongoose.Schema
const taskSchema = new Schema({
    title: {
        type: String,
        required: [true, 'title is mandatory']
    },
    description: {
        type: String
    },
    completed: {
        type: Boolean
    },
    dueDate: {
        type: Date
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
})

//create a model
const Task = mongoose.model('Task', taskSchema)

app.get('/', (req, res) => {
    res.send('welcome to the website')
})

app.get('/api/errors', () => {
    throw new Error('not authorized')
})

//tasks api
app.get('/api/tasks', (req, res) => {
    Task.find()
        .then((tasks) => {
            res.json(tasks)
        })
        .catch((err) => {
            res.json(err)
        })
})

app.get('/api/tasks/:id', (req, res) => {
    const id = req.params.id
    Task.findById(id)
        .then((task) => {
            res.json(task)
        })
        .catch((err) => {
            res.json(err)
        })
})

app.post('/api/tasks', (req, res) => {
    const body = req.body
    const task = new Task(body)
    task.save()
        .then((tasks) => {
            res.json(tasks)
        })
        .catch((err) => {
            res.json(err)
        })
    // task.title = body.title
    // task.description = body.description
    // task.completed = body.completed
    // task.dueDate = body.dueDate
    // task.createdAt = body.createdAt
})

app.put('/api/tasks/:id', (req, res) => {
    const id = req.params.id
    const body = req.body
    Task.findByIdAndUpdate(id, body, { new: true, runValidators: true })
        .then((task) => {
            res.json(task)
        })
        .catch((err) => {
            res.json(err)
        })
})

//new property is used in options object so that express sends the updated record and runvalidators is used because mongoose runs validations only on save operation on the database not on the update operation so we have to set the property so that even while updating the record validations are handled by the mongoose

app.delete('/api/tasks/:id', (req, res) => {
    const id = req.params.id
    Task.findByIdAndDelete(id)
        .then((task) => {
            res.json(task)
        })
        .catch((err) => {
            res.json(err)
        })
})

app.use((err, req, res, next) => {
    console.log('error handling middleware function')
    res.send(err.message)
})

app.listen(port, () => {
    console.log('listening to port', port)
})

/*
1.create
 static - called on a class / constructor function / Model
    Student.insertMany() -  static method to insert bunch of records at once.
 instance - called on an object / instance

 const stud = new Student()
 stud.save() - instance method

 2. Read
  static methods
   Student.find() -  all
   Student.findById()

3.update
static
Student.findByIdAndUpdate()

4.Destroy
static
Student.findByIdAndDelete()

on an object (ie individual) - instance method
on an collection - static method
*/